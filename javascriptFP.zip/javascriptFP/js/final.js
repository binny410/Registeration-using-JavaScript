
//CHECKING USERNAME AND PASSWORD VALUES.
//GIVING TIPS FOR USERNAME AND PASSWORD GENERATION.

var el = document.getElementById('username');
var elMsg = document.getElementById('feedback');

function checkUsername() {    // FUNCTION TO CHECK USERNAME LENGTH.
    var username = el.value;
    if (username.length < 5) {
        elMsg.className = 'warning';
        elMsg.textContent = 'Not long enough, yet...';
    } else {
        elMsg.textContent = '';
    }
}

function tipUsername() {    //TIP FOR USERNAME GENERATION FUNCTION
    elMsg.className = 'tip';
    elMsg.innerHTML = 'Username must be at least 5 character';
}

// Checking Password:
var el1 = document.getElementById('password');
var elMsg1 = document.getElementById('feedback1');

function checkPassword() {      //CHECKING PASSWORD PARAMETERS
    var password = el1.value;
    var valid = /^(?=.*[!@#$%^&*])/.test(el1.value);
   if (password.length < 8 && valid == false)
    {
    
     alert("Password must be 8 characters and contain at least one special character");

    }
    
   else 
    {
        if (password.length < 8 )       // IF PARAMETERS FOR PASSWORD IS NOT MET.
            alert("Password must be 8 characters");
        if (valid == false)
            alert("Password must contain at least one special character");
    } 
}

function tipPassword() {    //TIP FOR PASSWORD CREATION.
    elMsg1.className = 'tip';
    elMsg1.innerHTML = 'Password must be at least 8 character';
} 


//WHEN USERNAME INPUT GAINS OR LOSES FOCUS CALL FUNCTIONS.
if(el)
    {
      el.addEventListener('focus', tipUsername, false);
el.addEventListener('blur', checkUsername, false);
        // When the password input loses focus call functions above:
el1.addEventListener('blur', checkPassword, false);

    }


// Code to check wheather all details has been filled or not
function validate(){
    var usname  = document.getElementById('cnt').value;
    function validatePhone(phone) {
    var error = "";
    var stripped = phone.replace(/[\(\)\.\-\ ]/g, '');

   if (stripped == "") {
        error = "You didn't enter a phone number.";
    } else if (isNaN(parseInt(stripped))) {
        phone = "";
        error = "The phone number contains illegal characters.";

    } else if (!(stripped.length == 10)) {
        phone = "";
        error = "The phone number is the wrong length. Make sure you included an area code.\n";
    }
}

    
    
}

// CODE TO VALIDATE EMAIL ID
function ValidateEmail(mail)   
{  
 if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail))  
  {  
    return (true); 
  }  
    alert("You have entered an invalid email address!"); 
    return (false) ; 
}  

//LOG IN PAGE CODE
// Get the modal
var modal = document.getElementById('id01');
// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
var modal = document.getElementById('id01');
// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

// SLIDE SHOW NUMBER 1
var myIndex = 0;
carousel();
function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 2000); // Change image every 2 seconds
}

// SLIDE SHOW NUMBER 2
var myIndexx = 0;
carousel1();

function carousel1() {
    var h;
    var y = document.getElementsByClassName("mySlides1");
    for (h = 0; h < y.length; h++) {
       y[h].style.display = "none";  
    }
    myIndexx++;
    if (myIndexx > y.length) {myIndexx = 1}    
    y[myIndexx-1].style.display = "block";  
    setTimeout(carousel1, 2000); // Change image every 2 seconds
}

// SLIDE SHOW NUMBER 3
var myIndexs = 0;
carousel2();

function carousel2() {
    var f;
    var z = document.getElementsByClassName("mySlides2");
    for (f = 0; f < z.length; f++) {
       z[f].style.display = "none";  
    }
    myIndexs++;
    if (myIndexs > z.length) {myIndexs = 1}    
    z[myIndexs-1].style.display = "block";  
    setTimeout(carousel2, 2000); // Change image every 2 seconds
}

